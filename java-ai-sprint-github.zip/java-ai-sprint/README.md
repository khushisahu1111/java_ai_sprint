# Java AI Sprint

A beginner-friendly 30-day course that takes you from Java backend fundamentals to production AI backends with Spring Boot and Spring AI.

- **Start here**: 5 short primer lessons in plain language
- **30 daily lessons**: Learn → Practice → Quiz & review → Resources
- **Backend guide**: follow a request through the app, a clickable project map, and a glossary
- **Resource library**: free videos (including Hindi), courses, docs and repos
- Progress, notes, streak and XP are saved in your browser

It is a static site: one `index.html`, with no build step and no backend.

## Run locally
Double-click `index.html`, or run:
```bash
npx serve .
```

## Deploy

### GitHub Pages
1. In this repo go to **Settings → Pages**.
2. Under **Source**, choose **Deploy from a branch**, pick `main` and the `/ (root)` folder, then click **Save**.
3. After about a minute the site is live at `https://<your-username>.github.io/<repo-name>/`.

### Vercel
1. Go to https://vercel.com/new and import this repo.
2. Keep Framework Preset = **Other** and click **Deploy**.

## Files
| File | Purpose |
|------|---------|
| `index.html` | The whole site (HTML, CSS and JavaScript in one file) |
| `vercel.json` | Optional Vercel settings |
| `README.md` | This file |
